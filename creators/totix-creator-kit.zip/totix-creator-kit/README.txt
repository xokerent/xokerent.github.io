TOTIX CREATOR KIT  (v1.1, October 2026)
=======================================

Start with Totix-Creator-Brief.pdf: the game in 15 seconds, what films best,
must-dos (disclosure, your link, @totixgame) and the please-don'ts.

b-roll/     7 clean 9:16 gameplay clips, 1080x1920, 30 fps, game sound only
            double-quad ............... one tile completes two QUADs
            chain-x4-board-clear ...... four combos in a row, multiplier to x4, board clears
            treasure-hunt-3-stars ..... Level 12 finished with 3 stars
            zen-calm .................. Zen mode, three relaxed combos
            daily-event ............... today's Daily Event, a 3-4-5 sequence
            colorblind-shapes-chain ... the chain with Color-blind shapes switched on
            colorblind-shapes-double .. the double QUAD with shapes on
screens/    8 full-resolution screenshots (1206x2622)
mascot/     Toti in 6 poses, 1024x1024 transparent PNG
logo/       TOTIX wordmarks (transparent) + app icon 1024
stickers/   QUAD!, CHAIN x4, SEQUENCE!, COMBO!, 3 stars, NEW: ZEN MODE, #ad, and 6 tiles

You may use everything here in your Totix post. Please don't alter the logo
or present Toti as saying things he doesn't say in the game.

Your personal App Store link (it counts your installs):
https://apps.apple.com/app/apple-store/id6780786442?pt=129040531&ct=YOURTAG&mt=8

Questions: Murat Buldanlioglu, mbuldanlioglu@gmail.com
