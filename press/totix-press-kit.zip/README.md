# TOTIX — Press Kit

Everything a journalist or creator needs to write about **Totix: Number Match Puzzle**.

## What's in here

```
index.html                      ← the web press kit (open in any browser; host at e.g. totix.app/press)
FACT-SHEET.md                   ← copy-ready facts + descriptions
assets/
  logo/    totix-wordmark.svg, totix-icon-master.svg, toti-silhouette.svg, feature-graphic-1024x500.png
  icon/    totix-icon-1024.png
  mascot/  toti_{neutral,excited,awed,concerned,triumphant,sleepy}.svg   (6 poses, transparent)
  screenshots/  1–6, 1284×2778 PNG
  clips/   6 vertical gameplay clips (MP4, with audio)
```

## Asset usage

You're welcome to use any asset in this pack — screenshots, clips, logo, icon and the Toti mascot — in editorial coverage, videos, and social posts about Totix, free of charge. Please don't alter the logo or mascot artwork or imply an endorsement. A link back to the App Store listing is appreciated but not required.

## Hosting the web press kit

`index.html` is fully self-contained (fonts, images and a sample gameplay clip are embedded) — just drop it on any static host. Suggested URL: **totix.app/press**. On GitHub Pages, Netlify or Vercel, uploading this folder works out of the box.

## Before you publish — fill these in

- Studio location, official website URL, and social handles
- Public release / launch dates (iOS & Android)
- Final localized store prices
- Direct App Store & Google Play product links (the page buttons currently point to store search)
- A short developer bio / origin story
- Bundle this folder as a downloadable `.zip` and link it from the page's "Press assets" section

## Contact

**mbuldanlioglu@gmail.com** — happy to send review/promo codes, extra assets, or answer anything.
