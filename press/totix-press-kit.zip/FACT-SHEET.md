# TOTIX — Press Fact Sheet

> Copy-ready facts and descriptions for journalists and content creators.
> Fields marked **[confirm]** need your input before publishing.

---

## At a glance

| | |
|---|---|
| **Title** | Totix: Number Match Puzzle |
| **Tagline** | Place. Match. Cascade. |
| **Developer** | Murat Buldanlıoğlu (independent) |
| **Based in** | **[confirm — city, country]** |
| **Release** | iOS — live on the App Store · Android — in closed testing (public date **[confirm]**) |
| **Platforms** | iOS 15.0+ (App Store) · Android 6.0+ / API 23 (Google Play) |
| **Latest version** | 1.0.1 |
| **Price** | Free to play, with optional in-app purchases |
| **Genre** | Casual tile-matching / combo-cascade puzzle |
| **Players** | Single-player |
| **Modes** | 6 (Campaign, Training Arena, Daily Event, Weekly League, Daily Quests, Leaderboards) |
| **Languages** | English (Spanish–LatAm & Portuguese–BR store listings in progress) |
| **Bundle ID** | com.totix.game |
| **Website** | **[confirm]** |
| **Press contact** | mbuldanlioglu@gmail.com |
| **Social** | **[confirm — add handles]** |

---

## Descriptions

**One-liner**
A cozy, underwater number-matching puzzle where you drop numbered tiles onto a 4×4 board and line up Color, Number & Sequence combos that cascade into huge scores.

**Short (Google Play, ≤80 chars)**
Cozy number match puzzle. Line up colors, chain cascade combos, relax & win!

**Subtitle (App Store, ≤30 chars)**
Cozy tile combo brain game

**Full description (App Store, verbatim v1.0.1)**

> Place. Match. Cascade!
>
> Totix is a cozy number-matching puzzle. Drop colorful numbered tiles onto the board and line up matches by COLOR, NUMBER, or SEQUENCE — then trigger satisfying cascade combos (TRIPLES, QUADS, and SEQUENCES) that chain into huge scores. Easy to learn, hard to put down.
>
> SIMPLE TO PLAY, SATISFYING TO MASTER
> Place a tile, match three or more, and watch the cascade combos explode across the board.
>
> THREE WAYS TO MATCH
> Colors, numbers, and sequences — plan your drops, build chains, clear the board.
>
> MODES FOR EVERY MOOD
> • Campaign — hand-crafted number-puzzle levels
> • Training Arena — endless score-chasing runs
> • Daily Events & Weekly League — fresh challenges every day
> • Global Leaderboards — climb the ranks worldwide
>
> COZY, RELAXING & OFFLINE
> A calm pastel world with a friendly mascot. Play offline, anytime. Color-blind friendly — every tile carries a distinct shape, not just a color.
>
> Free to play. Place. Match. Cascade!

---

## Key features

- 4×4 drop-and-match board with three combo families: **Color, Number & Sequence**
- **Triples and Quads** that cascade into chain reactions — placement-driven, with escalating score multipliers
- **No gravity:** cleared tiles stay in place, so every chain is one you engineered — not luck
- **Rarity-aware scoring** — combos pay more as the deck escalates, so deep runs mean massive scores
- **Ten strategic boosters** (Freeze Time, Bomb, Mini Bomb, Color Bomb, Wildcard Draw, Quad Charge, Swap, Shuffle, Destroy Tile, Peek+1)
- **50-level hand-crafted Campaign** ("Treasure Hunt", World 1) with star objectives, locked cards and power slots
- **Endless Training Arena** with real-time deck escalation
- **Daily Event** (seeded, best-of-3) and **Weekly League** with global leaderboards
- **Daily Quests** that scale to your skill, plus a 30-day login calendar
- Friendly mascot **Toti** with unlockable avatar costumes
- **Fully playable offline;** deterministic seeded scoring enables server-side verification
- **Color-blind friendly** — distinct shapes on every tile

---

## How it plays (mechanics)

- **The board:** 16 slots (4×4). Combos form on rows, columns and diagonals.
- **Three families & base scores (Triple / Quad):**
  - Color (same color) — **100 / 250**
  - Number (same number) — **150 / 375**
  - Sequence (a consecutive run) — **250 / 625**
- **Cascades:** there is no gravity — a single placement can complete several crossing lines at once, and each chain step multiplies your score (**×1 → ×1.5 → ×2.5 → ×4 → ×6 → …and up**).
- **Depth:** as the draw pool grows, combos get rarer and scoring scales up to match — turning a relaxed session into a real high-score chase.

## Accessibility

- Color-blind shapes mode (a distinct symbol on every tile)
- High-contrast, deuteranopia-safe palette
- Reduce motion (can follow the OS setting)
- Larger text · adjustable drag sensitivity · portrait & landscape

## Business model

Free to download, funded by ads and optional purchases. Ads stay out of the way — none during a new player's first session, capped per session, and **never** shown to anyone who has made a purchase. Rewarded ads are opt-in (revive a run, double a reward, spin the daily wheel). One-time "Remove Ads" plus coin & booster packs and a Starter Pack. Prices are localized per store; earned in-game gems are never sold.

## Built with

TypeScript · Phaser 3 · Preact · Capacitor 7 · Firebase (Auth, Firestore, Analytics/GA4, Remote Config) · RevenueCat · AdMob · seeded deterministic RNG for verifiable scores.

---

## About the developer

Totix is made by **Murat Buldanlıoğlu**, an independent developer. **[confirm — 2–3 sentence personal bio / why you built Totix; studio name if any.]**

## Awards & press

No awards or press coverage yet — Totix is newly launched. Coverage and review codes are warmly welcomed; get in touch below.

## Contact

- **Press & review codes:** mbuldanlioglu@gmail.com
- **Web press kit:** **[confirm — e.g. totix.app/press]**

---

### To confirm before publishing
- [ ] Studio location, official website URL, social handles
- [ ] Public release / launch dates (iOS & Android)
- [ ] Final localized store prices
- [ ] Direct App Store & Google Play product links
- [ ] Developer bio / origin story
